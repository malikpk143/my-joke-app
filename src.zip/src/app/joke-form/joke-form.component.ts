import { Component, OnInit } from '@angular/core';
import { Form, FormControl,  } from '@angular/forms';
import { JokeListComponent } from '../joke-list/joke-list.component';
import { Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
import {Joke } from '../Joke';

@Component({
  selector: 'joke-form',
  templateUrl: './joke-form.component.html',
  styleUrls: ['./joke-form.component.css']
})
export class JokeFormComponent implements OnInit {

@Output() jokeCreated=new EventEmitter<Joke>();

  createJoke(setup:string,punchline:string){
    this.jokeCreated.emit(new Joke(setup,punchline));
  }
  constructor() { }

  ngOnInit() {
  }

}
