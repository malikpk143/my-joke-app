import { Component, OnInit } from '@angular/core';
import { Joke } from '../Joke';
import { Form, FormControl,  } from '@angular/forms';
import { Input } from '@angular/core';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'joke',
  templateUrl: './joke.component.html',
  styleUrls: ['./joke.component.css']
})
export class JokeComponent implements OnInit {
  @Input('joke') data:Joke;
  constructor() { }
  ngOnInit() {
  }
}
