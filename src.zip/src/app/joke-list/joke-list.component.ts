import { Component, OnInit } from '@angular/core';
import {Joke } from '../Joke';
import { JokeComponent } from '../joke/joke.component';


@Component({
  selector: 'joke-list',
  templateUrl: './joke-list.component.html',
  styleUrls: ['./joke-list.component.css']
})
export class JokeListComponent implements OnInit {
  jokes:Joke[];
  constructor() { 
    this.jokes=[
      new Joke('First Joke','First Punchline'),
      new Joke('Second Joke','Second Punchline'),
      new Joke('Third Joke','Third Punchline')
    ];
  }
  addJoke(joke){
    
      this.jokes.unshift(joke);
       
  }
  ngOnInit() {
  }

}
